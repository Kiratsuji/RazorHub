<?php
    require_once("config/database.php");
   
    //Se já estiver logado, redirecione a tela inicial
    if (isset($_SESSION["user_id"])) {
        header("Location: inicio.php");
        exit();
    }
?>
<!doctype html>
<html lang="pt-BR" data-bs-theme="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RazorHub</title>

    <link
      href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:wght@300;400;600&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="../css/style.css" />

    <link
      rel="icon"
      type="image/png"
      href="assets/images/favicon/favicon-96x96.png"
      sizes="96x96"
    />
    <link
      rel="icon"
      type="image/svg+xml"
      href="assets/images/favicon/favicon.svg"
    />
    <link rel="shortcut icon" href="assets/images/favicon/favicon.ico" />
    <link
      rel="apple-touch-icon"
      sizes="180x180"
      href="assets/images/favicon/apple-touch-icon.png"
    />
    <meta name="apple-mobile-web-app-title" content="RazorHub" />
    <link rel="manifest" href="assets/images/favicon/site.webmanifest" />
  </head>
  <body>
    <header>
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="#">RazorHub</a>
          <div class="d-flex gap-2">
            <a href="login.php" class="btn btn-ghost btn-sm px-3 py-2"
              >Login</a
            >
            <a href="register.php" class="btn btn-gold btn-sm px-3 py-2"
              >Registrar</a
            >
          </div>
        </div>
      </nav>
    </header>

    <main>
      <section class="hero">
        <div class="container">
          <div class="row">
            <div class="col-lg-7">
              <p class="hero-eyebrow mb-3">
                Barbearia Premium &mdash; Santa Luzia
              </p>
              <h1 class="hero-title mb-4">
                CORTE<br />
                DE <span>ALTO</span><br />
                NÍVEL
              </h1>
              <hr class="hero-divider mb-4" />
              <p class="hero-lead mb-5">
                Bem-vindo à RazorHub. Se já for cliente, faça login para ver
                seus agendamentos. Novo por aqui? Registre-se e venha nos
                conhecer.
              </p>
              <div class="d-flex flex-wrap gap-3">
                <a href="register.php" class="btn btn-gold px-4 py-2"
                  >Registrar agora</a
                >
                <a href="login.php" class="btn btn-ghost px-4 py-2"
                  >Já tenho conta</a
                >
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="py-6" style="padding: 5rem 0">
        <div class="container">
          <div class="mb-5">
            <p class="section-label mb-2">O que oferecemos</p>
            <h2 class="section-title mb-0">NOSSOS SERVIÇOS</h2>
          </div>
          <div class="row g-4">
            <div class="col-md-6 col-lg-3">
              <div class="service-card">
                <span class="service-icon">✂</span>
                <h5>Corte Clássico</h5>
                <p>
                  Tesoura, máquina ou navalha — o corte certo para o seu estilo.
                </p>
              </div>
            </div>
            <div class="col-md-6 col-lg-3">
              <div class="service-card">
                <span class="service-icon">🪒</span>
                <h5>Barba & Navalha</h5>
                <p>
                  Acabamento quente com toalha e navalha para uma barba
                  impecável.
                </p>
              </div>
            </div>
            <div class="col-md-6 col-lg-3">
              <div class="service-card">
                <span class="service-icon">💆</span>
                <h5>Tratamento Capilar</h5>
                <p>
                  Hidratação e cuidados que deixam o cabelo com saúde e brilho.
                </p>
              </div>
            </div>
            <div class="col-md-6 col-lg-3">
              <div class="service-card">
                <span class="service-icon">📅</span>
                <h5>Agendamento Online</h5>
                <p>Marque seu horário pelo app sem filas e sem complicação.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="cta-section py-5">
        <div class="container text-center py-4">
          <p class="section-label mb-3">Pronto para começar?</p>
          <h2 class="cta-title mb-4">AGENDE SEU HORÁRIO</h2>
          <p
            class="mb-4"
            style="color: #7a776e; max-width: 440px; margin: 0 auto 2rem"
          >
            Crie sua conta gratuitamente e garanta seu lugar na cadeira.
          </p>
          <a href="register.php" class="btn btn-gold px-5 py-2 me-2"
            >Criar conta</a
          >
          <a href="login.php" class="btn btn-ghost px-5 py-2">Fazer login</a>
        </div>
      </section>
    </main>

    <footer class="py-4">
      <div
        class="container d-flex flex-wrap justify-content-between align-items-center"
      >
        <span class="footer-brand">RazorHub</span>
        <p class="footer-copy mb-0">
          Todos os direitos reservados &copy; 2026 RazorHub
        </p>
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YUe2LzesAfRqEkBRFTkMoPNmQhkGIl+e+0gDsAk51nV+oHnTBBW8OxkIGIVDCk3"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
